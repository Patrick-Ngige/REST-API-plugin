<?php
/*
Plugin Name: Ecommerce API Plugin
Description: REST API endpoints for e-commerce products.
*/

// Create a product
function ecommerce_api_create_product(WP_REST_Request $request) {
    $name = $request->get_param('name');
    $price = $request->get_param('price');
    $description = $request->get_param('description');

    // Save the product to the database
    $product_id = wp_insert_post(array(
        'post_title' => $name,
        'post_content' => $description,
        'post_status' => 'publish',
        'post_type' => 'product',
    ));

    // Add custom fields for price
    update_post_meta($product_id, 'price', $price);

    // Return the product ID
    return rest_ensure_response(array('id' => $product_id));
}

// Get all products
function ecommerce_api_get_products() {
    $products = get_posts(array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'numberposts' => -1,
    ));

    $formatted_products = array();
    foreach ($products as $product) {
        $formatted_products[] = array(
            'id' => $product->ID,
            'name' => $product->post_title,
            'price' => get_post_meta($product->ID, 'price', true),
            'description' => $product->post_content,
        );
    }

    return rest_ensure_response($formatted_products);
}

// Get a specific product
function ecommerce_api_get_product(WP_REST_Request $request) {
    $product_id = $request->get_param('id');

    $product = get_post($product_id);
    if (!$product) {
        return new WP_Error('product_not_found', 'Product not found', array('status' => 404));
    }

    $formatted_product = array(
        'id' => $product->ID,
        'name' => $product->post_title,
        'price' => get_post_meta($product->ID, 'price', true),
        'description' => $product->post_content,
    );

    return rest_ensure_response($formatted_product);
}

// Update a product
function ecommerce_api_update_product(WP_REST_Request $request) {
    $product_id = $request->get_param('id');
    $name = $request->get_param('name');
    $price = $request->get_param('price');
    $description = $request->get_param('description');

    $product = get_post($product_id);
    if (!$product) {
        return new WP_Error('product_not_found', 'Product not found', array('status' => 404));
    }

    $updated_product = array(
        'ID' => $product_id,
        'post_title' => $name,
        'post_content' => $description,
    );
    wp_update_post($updated_product);

    // Update custom fields for price
    update_post_meta($product_id, 'price', $price);

    $formatted_product = array(
        'id' => $product_id,
        'name' => $name,
        'price' => $price,
        'description' => $description,
    );

    return rest_ensure_response($formatted_product);
}

// Delete a product
function ecommerce_api_delete_product(WP_REST_Request $request) {
    $product_id = $request->get_param('id');

    $product = get_post($product_id);
    if (!$product) {
        return new WP_Error('product_not_found', 'Product not found', array('status' => 404));
    }

    wp_delete_post($product_id, true);

    return rest_ensure_response(array('message' => 'Product deleted successfully'));
}

// Register the API routes
function ecommerce_api_register_routes() {
    register_rest_route('ecommerce-api/v1', '/products', array(
        'methods' => 'POST',
        'callback' => 'ecommerce_api_create_product',
    ));

    register_rest_route('ecommerce-api/v1', '/products', array(
        'methods' => 'GET',
        'callback' => 'ecommerce_api_get_products',
    ));

    register_rest_route('ecommerce-api/v1', '/products/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'ecommerce_api_get_product',
    ));

    register_rest_route('ecommerce-api/v1', '/products/(?P<id>\d+)', array(
        'methods' => 'PUT',
        'callback' => 'ecommerce_api_update_product',
    ));

    register_rest_route('ecommerce-api/v1', '/products/(?P<id>\d+)', array(
        'methods' => 'DELETE',
        'callback' => 'ecommerce_api_delete_product',
    ));
}
add_action('rest_api_init', 'ecommerce_api_register_routes');
